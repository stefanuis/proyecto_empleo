class Config:
    SECRET_KEY = "clave-super-secreta"
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://hojero:estaEsmiSeguridad2025*@192.168.2.138:3306/hojas"
    SQLALCHEMY_TRACK_MODIFICATIONS = False