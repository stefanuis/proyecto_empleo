function togglePw() {
  const input = document.getElementById('password');
  const icon = document.getElementById('eye-icon');
  if (input.type === 'password') {
    input.type = 'text';
    icon.innerHTML = `<path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>`;
  } else {
    input.type = 'password';
    icon.innerHTML = `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
  }
}

function handleSubmit(e) {
  e.preventDefault();
  const btn = e.target.querySelector('.btn-submit');
  const label = btn.querySelector('.btn-text');
  const chevron = btn.querySelector('.btn-chevron');

  btn.disabled = true;
  label.textContent = 'Verificando...';
  chevron.style.display = 'none';

  // Animate button
  btn.style.background = 'var(--primary-hover)';

  setTimeout(() => {
    label.textContent = '✓ Acceso concedido';
    btn.style.background = '#2E7D32';
    btn.style.boxShadow = '0 6px 20px rgba(46,125,50,0.35)';

    setTimeout(() => {
      btn.disabled = false;
      label.textContent = 'Iniciar sesión';
      btn.style.background = '';
      btn.style.boxShadow = '';
      chevron.style.display = '';
      alert('¡Login exitoso! (demo)');
    }, 1500);
  }, 2000);
}
