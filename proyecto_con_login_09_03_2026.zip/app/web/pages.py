from flask import render_template
from . import web_bp

@web_bp.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")