from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, create_refresh_token
from datetime import datetime, timezone, timedelta
from app.models.user import User
from app.extensions import db

# ─────────────────────────────────────────────────────────────
#  BLUEPRINT
#  Un Blueprint agrupa rutas relacionadas.
#  "auth" es el nombre interno; url_prefix aplica a todas sus rutas.
#  Resultado: esta ruta vivirá en  POST /api/auth/login
# ─────────────────────────────────────────────────────────────
auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Endpoint de autenticación.

    Espera un JSON con:
        { "correo": "...", "clave": "..." }

    Devuelve:
        200 → { access_token, refresh_token, usuario: {...} }
        400 → campos faltantes
        401 → credenciales inválidas
        403 → cuenta inactiva o no verificada
    """

    # ── 1. LEER EL BODY ──────────────────────────────────────
    # request.get_json() parsea el body como JSON.
    # silent=True evita que explote si el body no es JSON válido
    # (devuelve None en ese caso).
    data = request.get_json(silent=True)

    # Si no llegó nada o no es JSON, respondemos con error.
    if not data:
        return jsonify({"error": "Se esperaba un JSON en el body"}), 400

    # ── 2. VALIDAR CAMPOS REQUERIDOS ─────────────────────────
    correo = data.get("correo", "").strip().lower()
    clave  = data.get("clave", "").strip()

    # .strip() elimina espacios accidentales al inicio/fin.
    # .lower() normaliza el correo para evitar duplicados por mayúsculas.
    if not correo or not clave:
        return jsonify({"error": "Correo y clave son obligatorios"}), 400

    # ── 3. BUSCAR USUARIO EN LA BD ───────────────────────────
    # filter_by genera un SELECT ... WHERE correo = :correo
    # first() trae el primer resultado o None si no existe.
    usuario = User.query.filter_by(correo=correo).first()

    # ── 4. VERIFICAR EXISTENCIA Y CONTRASEÑA ─────────────────
    # Importante: primero comprobamos que el usuario exista Y LUEGO
    # la contraseña en el MISMO mensaje de error.
    # Esto evita revelar si un correo está o no registrado (enumeración).
    if not usuario or not usuario.check_password(clave):
        return jsonify({"error": "Credenciales inválidas"}), 401

    # ── 5. VERIFICAR ESTADO DE LA CUENTA ─────────────────────
    if not usuario.esta_activa:
        return jsonify({"error": "Cuenta desactivada. Contacta al administrador"}), 403

    if not usuario.esta_verificada:
        return jsonify({"error": "Debes verificar tu correo antes de ingresar"}), 403

    # ── 6. GENERAR TOKENS JWT ────────────────────────────────
    # identity: identificador único que se guarda DENTRO del token.
    #           Usamos el ID del usuario (entero).
    # additional_claims: datos extra que viajan en el payload del JWT.
    #           Son visibles (no encriptados), así que no pongas info sensible.
    claims = {
        "rol":      usuario.rol,
        "correo":   usuario.correo,
        "nombres":  usuario.nombres,
    }

    # access_token  → vida corta (15 min). Se usa en cada request protegido.
    # refresh_token → vida larga (7 días). Solo sirve para pedir un nuevo access_token.
    access_token  = create_access_token(
        identity=str(usuario.id),
        additional_claims=claims,
        expires_delta=timedelta(minutes=15)
    )
    refresh_token = create_refresh_token(
        identity=str(usuario.id),
        expires_delta=timedelta(days=7)
    )

    # ── 7. ACTUALIZAR ÚLTIMO LOGIN ───────────────────────────
    # Registramos la fecha/hora exacta en que el usuario ingresó.
    usuario.ultimo_login = datetime.now(timezone.utc)
    db.session.commit()  # Guardamos el cambio en la BD.

    # ── 8. RESPUESTA EXITOSA ─────────────────────────────────
    return jsonify({
        "access_token":  access_token,
        "refresh_token": refresh_token,
        "token_type":    "Bearer",        # Estándar para JWT en headers HTTP
        "usuario": {
            "id":       usuario.id,
            "nombres":  usuario.nombres,
            "apellidos":usuario.apellidos,
            "correo":   usuario.correo,
            "rol":      usuario.rol,
        }
    }), 200


# ─────────────────────────────────────────────────────────────
#  BONUS: Ruta para renovar el access_token usando el refresh_token
#  El frontend la llama cuando el access_token expira (error 401).
# ─────────────────────────────────────────────────────────────
from flask_jwt_extended import jwt_required, get_jwt_identity

@auth_bp.route("/refresh", methods=["POST"])
@jwt_required(refresh=True)   # Solo acepta refresh tokens, no access tokens
def refresh():
    """
    Renueva el access_token.
    Header requerido:  Authorization: Bearer <refresh_token>
    """
    identity = get_jwt_identity()  # Extrae el ID del usuario del token
    nuevo_access = create_access_token(
        identity=identity,
        expires_delta=timedelta(minutes=15)
    )
    return jsonify({"access_token": nuevo_access}), 200




    