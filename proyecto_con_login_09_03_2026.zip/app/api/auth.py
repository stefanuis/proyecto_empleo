from flask import request, jsonify
from . import api_bp

@api_bp.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    correo = data.get("correo")
    clave = data.get("clave")

    if correo == "admin@test.com" and clave == "123":
        return jsonify({"token": "fake-jwt"})

    return jsonify({"error": "Credenciales incorrectas"}), 401