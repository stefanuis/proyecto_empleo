from app.extensions import db
from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash

# ─────────────────────────────────────────────
#  MODELO: User
#  Representa la tabla "user" en la base de datos.
#  SQLAlchemy mapea cada db.Column a una columna real en SQL.
# ─────────────────────────────────────────────
class User(db.Model):

    # __tablename__ define el nombre de la tabla en la BD.
    # Si no lo pones, SQLAlchemy usa el nombre de la clase en minúscula ("user").
    __tablename__ = "tbl_usuario"

    # ── Identificador único ──────────────────
    # primary_key=True → es la PK de la tabla, se autoincrementa.
    id = db.Column(db.Integer, primary_key=True)

    # ── Datos personales ─────────────────────
    # nullable=False → el campo NO puede quedar vacío en la BD.
    nombres  = db.Column(db.String(100), nullable=False)
    apellidos = db.Column(db.String(100), nullable=False)

    # unique=True → no pueden existir dos usuarios con el mismo correo.
    # index=True  → crea un índice en la BD para búsquedas más rápidas.
    correo   = db.Column(db.String(150), unique=True, nullable=False, index=True)
    telefono = db.Column(db.String(20))

    # ── Seguridad ────────────────────────────
    # Nunca guardamos la contraseña en texto plano.
    # Aquí se almacena el HASH generado por werkzeug.
    clave_hash = db.Column(db.String(255), nullable=False)

    # ── Flags de estado ──────────────────────
    # default=True  → toda cuenta nueva empieza activa.
    # default=False → toda cuenta nueva empieza sin verificar.
    esta_activa     = db.Column(db.Boolean, default=True,  nullable=False)
    esta_verificada = db.Column(db.Boolean, default=False, nullable=False)

    # ── Timestamps ───────────────────────────
    # datetime.now(timezone.utc) → se ejecuta al crear el registro (hora UTC).
    # onupdate → SQLAlchemy lo actualiza automáticamente en cada UPDATE.
    fecha_creacion       = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    fecha_actualizacion  = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc),
                                     onupdate=lambda: datetime.now(timezone.utc))
    ultimo_login         = db.Column(db.DateTime, nullable=True)  # None hasta que haga su 1er login

    # ── Rol ──────────────────────────────────
    # Ejemplos de valores: "admin", "usuario", "moderador"
    rol = db.Column(db.String(50), default="usuario", nullable=False)

    # ─────────────────────────────────────────
    #  MÉTODOS DE CONTRASEÑA
    #  Encapsulamos el hashing dentro del modelo para
    #  no repetir lógica en otros archivos.
    # ─────────────────────────────────────────

    def set_password(self, clave_plana: str):
        """Recibe la contraseña en texto plano y guarda su hash."""
        # generate_password_hash usa pbkdf2:sha256 por defecto (seguro).
        self.clave_hash = generate_password_hash(clave_plana)

    def check_password(self, clave_plana: str) -> bool:
        """Compara una contraseña ingresada contra el hash almacenado.
        Devuelve True si coinciden, False si no.
        """
        return check_password_hash(self.clave_hash, clave_plana)

    # ─────────────────────────────────────────
    #  REPRESENTACIÓN
    #  Útil para debugging: print(user) → <User 1 - juan@mail.com>
    # ─────────────────────────────────────────
    def __repr__(self):
        return f"<User {self.id} - {self.correo}>"