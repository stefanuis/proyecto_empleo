from flask import Flask

from .extensions import db
from .api import api_bp
from .web import web_bp

def create_app():
    app = Flask(__name__)

    app.config.from_object("config.Config")

    db.init_app(app)

    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    return app